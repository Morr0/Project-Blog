const dynamoose = require("dynamoose");

exports.Post = require("./postsModels");
exports.Contact = require("./contactModels");